from pandas import DataFrame, Series, concat, merge

from m4i_analytics.graphs.languages.archimate.ArchimateUtils import ElementType
from m4i_analytics.graphs.languages.archimate.model.ArchimateModel import (
    ArchimateModel, NodeAttribute)


def filter_nodes_of_type(model: ArchimateModel, type: str) -> ArchimateModel:
    resolved_type = ElementType.getElementByTag(type)

    if resolved_type is None:
        raise ValueError(f"{type} could not be resolved to an element type")
    # END IF

    nodes = model.nodes
    is_of_type = nodes[model.getNodeAttributeMapping(
        NodeAttribute.TYPE)] == resolved_type
    model.nodes = nodes[is_of_type]

    return model
# END filter_nodes_of_type
