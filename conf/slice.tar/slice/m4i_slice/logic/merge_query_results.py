from pandas import DataFrame, concat

from m4i_analytics.graphs.languages.archimate.model.ArchimateModel import \
    ArchimateModel


def merge_query_results(
    operator: str,
    query_result: ArchimateModel,
    nodes: DataFrame = None,
    edges: DataFrame = None,
    views: DataFrame = None,
    organizations: DataFrame = None
):

    def resolve(concepts: DataFrame, other_concepts: DataFrame, id_key: str):

        def resolve_and():
            intersection = concepts[id_key].isin(other_concepts[id_key])
            return concepts[intersection]
        # END resolve_and

        def resolve_or():
            return concat([concepts, other_concepts]).drop_duplicates(subset=[id_key])
        # END resolve_or

        resolvers = {
            'and': resolve_and,
            'or': resolve_or
        }

        resolver = resolvers.get(operator)

        if resolver is None:
            raise ValueError(f'Unknown query merge resolver {operator}')
        # END IF

        if concepts is None:
            return other_concepts
        # END IF

        return resolver()
    # END resolve

    return (
        resolve(nodes, query_result.nodes, 'id'),
        resolve(edges, query_result.edges, 'id'),
        resolve(views, query_result.views, 'id'),
        resolve(organizations, query_result.organizations, 'idRef')
    )
# END merge_query_results
