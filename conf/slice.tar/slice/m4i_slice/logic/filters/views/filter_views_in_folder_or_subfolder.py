from typing import Iterable

from pandas import Series

from m4i_analytics.graphs.languages.archimate.model.ArchimateModel import (
  ArchimateModel, ViewAttribute)


def filter_views_in_folder_or_subfolder(model: ArchimateModel, path: Iterable[str]) -> ArchimateModel:
    organizations = model.organizations

    views = model.views
    view_ids = set(views[model.getViewAttributeMapping(ViewAttribute.ID)])

    length_of_path = len(path)

    def is_view_and_in_folder_or_subfolder(organization: Series):
        id_ref, *current_path = organization.values

        # Filter `None` values introduced by the dataframe out of the path
        fmt_current_path = [
            folder for folder in current_path
            if folder is not None
        ]

        return id_ref not in view_ids or (length_of_path >= len(fmt_current_path) and fmt_current_path[:len(path)] == path)
    # END is_view_and_in_folder_or_subfolder

    model.organizations = organizations[
        organizations.apply(is_view_and_in_folder_or_subfolder, axis=1)
    ]

    return model
# END filter_views_in_folder_or_subfolder
