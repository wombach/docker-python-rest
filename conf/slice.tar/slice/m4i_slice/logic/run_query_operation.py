from m4i_analytics.graphs.languages.archimate.model.ArchimateModel import \
  ArchimateModel

from .filters import filter_nodes_of_type, filter_views_in_folder_or_subfolder

node_operations = {
    'type': filter_nodes_of_type
}

view_operations = {
    'in_folder_or_subfolder': filter_views_in_folder_or_subfolder,
}

operations_by_type = {
    'node': node_operations,
    'view': view_operations
}


def run_query_operation(model: ArchimateModel, type: str, filter: str, params: dict) -> ArchimateModel:
    operations = operations_by_type[type]
    operation = operations[filter]
    return operation(model, **params)
# END run_query_operation
