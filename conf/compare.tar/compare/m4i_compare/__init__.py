from .compare import app
