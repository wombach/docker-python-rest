import json
from typing import Iterable, Tuple

from flask import Flask, request

from m4i_analytics.graphs.languages.archimate.ArchimateUtils import \
    ArchimateUtils
from m4i_backend_core.auth import requires_auth
from m4i_backend_core.shared import register as register_shared

from .logic import run_query

app = Flask(__name__)

# Register the shared core module with the application
register_shared(app)


@app.route('/', methods=['POST'])
@requires_auth
def slice(access_token=None):

    # Retrieve model parameters
    project = request.form.get('project')
    branch = request.form.get('branchName')
    version = request.form.get(
        'version') if 'version' in request.args else None

    # Structure the request parameters
    model_options = {
        'fullProjectName': project,
        'branchName': branch,
        'version': version,
        'userid': 'slice'
    }

    # Retrieve the model to be sliced
    model = ArchimateUtils.load_model_from_repository(
        **model_options,
        access_token=access_token
    )

    # Deserialize the query
    query = json.loads(request.form.get('query'))

    # Slice the model
    sliced_model = run_query(
        model=model,
        query=query['query']
    )

    # Serialize the model to JSON
    model_json = ArchimateUtils.to_JSON(sliced_model)

    return model_json
# END compare
