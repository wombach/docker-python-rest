from typing import Iterable

from pandas import DataFrame, concat


def cleanup_nodes(nodes: DataFrame, organizations: DataFrame):
    return nodes[nodes['id'].isin(organizations['idRef'])]
# END cleanup_nodes


def cleanup_edges(nodes: DataFrame, edges: DataFrame, organizations: DataFrame):
    ids = concat([nodes['id'], edges['id']])
    return edges[edges['id'].isin(organizations['idRef']) & edges['source'].isin(ids) & edges['target'].isin(ids)]
# END cleanup_edges


def cleanup_views(nodes: DataFrame, edges: DataFrame, views: DataFrame, organizations: DataFrame):
    concept_ids = set(concat([nodes['id'], edges['id']]).values)

    def cleanup_view_connections(connections: Iterable[dict]):
        if connections is None:
            return
        # END IF
        for connection in connections:
            if '@relationshipRef' not in connection or connection['@relationshipRef'] in concept_ids:
                yield connection
            # END IF
        # END LOOP
    # END cleanup_view_connections

    def cleanup_view_nodes(nodes: Iterable[dict]):
        if nodes is None:
            return
        # END IF

        for node in nodes:
            if '@elementRef' not in node or node['@elementRef'] in concept_ids:
                if 'ar3_node' in node:
                    node['ar3_node'] = list(
                        cleanup_view_nodes(node['ar3_node'])
                    )
                # END IF
                yield node
            # END IF
        # END LOOP
    # END LOOP

    views_in_organizations = views[views['id'].isin(organizations['idRef'])]

    for index, view in views_in_organizations.iterrows():
        view.nodes = list(cleanup_view_nodes(view.nodes))
        view.connections = list(cleanup_view_connections(view.connections))

        if(len(view.nodes) > 0 and len(view.connections) > 0):
            yield view
        # END IF
    # END LOOP
# END cleanup_views


def cleanup_organizations(nodes: DataFrame, edges: DataFrame, views: DataFrame, organizations: DataFrame):
    concept_ids = concat([nodes['id'], edges['id'], views['id']])
    return organizations[organizations['idRef'].isin(concept_ids)]
# END cleanup_organizations


def check_consistency(nodes: DataFrame, edges: DataFrame, views: DataFrame, organizations: DataFrame):

    cleaned_nodes = cleanup_nodes(
        nodes=nodes,
        organizations=organizations
    )
    cleaned_edges = cleanup_edges(
        nodes=nodes,
        edges=edges,
        organizations=organizations
    )
    cleaned_views = DataFrame(cleanup_views(
        nodes=nodes,
        edges=edges,
        views=views,
        organizations=organizations
    ))
    cleaned_organizations = cleanup_organizations(
        nodes=nodes,
        edges=edges,
        views=views,
        organizations=organizations
    )
    return cleaned_nodes, cleaned_edges, cleaned_views, cleaned_organizations
# END check_consistency
