from typing import Iterable

from m4i_analytics.graphs.languages.archimate.model.ArchimateModel import \
    ArchimateModel

from .cleanup import check_consistency
from .merge_query_results import merge_query_results
from .run_query_operation import run_query_operation


def run_query_group(group: dict, model: ArchimateModel) -> ArchimateModel:

    operator = group['operator']

    if not operator:
        raise ValueError(f"A query group must contain an operator")
    # END IF

    operations = group['operations']

    if not operations:
        raise ValueError(f"A query should define at least one filter")
    # END IF

    nodes = None
    edges = None
    views = None
    organizations = None

    for operation in operations:
        filtered_model = run_query_operation(model, **operation)

        nodes, edges, views, organizations = merge_query_results(
            operator=operator,
            query_result=filtered_model,
            nodes=nodes,
            edges=edges,
            views=views,
            organizations=organizations
        )
    # END LOOP

    nodes, edges, views, organizations = check_consistency(
        nodes=nodes,
        edges=edges,
        views=views,
        organizations=organizations
    )

    model.nodes = nodes
    model.edges = edges
    model.views = views
    model.organizations = organizations

    return model
# END run_query_group


def run_query(query: Iterable[dict], model: ArchimateModel) -> ArchimateModel:
    result = model
    for group in query:
        result = run_query_group(group, result)
    # END LOOP
    return result
# END run_query
